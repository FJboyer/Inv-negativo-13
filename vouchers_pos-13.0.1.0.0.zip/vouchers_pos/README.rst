
Coupons & Vouchers in Point of Sale V13
=======================================

This module allow special discounts to your customers using Gift Vouchers and Coupon codes.

Depends
=======
[point_of_sale] addon Odoo


Installation
============

- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon

Credits
=======
* Cybrosys Techno Solutions<https://www.cybrosys.com>

Author
------

Developers: v10.0 LINTO CT <odoo@cybrosys.com>
	    v11.0 LINTO CT 
            v12.0 Kavya Raveendran
	    v13.0 Varsha Vivek

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.

